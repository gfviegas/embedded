#include <ex2.h>

void main () {
	runInterrupt();
}
